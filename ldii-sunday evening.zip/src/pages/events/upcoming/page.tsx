export default function UpcomingEventsPage() {
  const upcomingEvents = [
    {
      title: 'Global Shocks Global South Conference 2026',
      date: 'TBA 2026',
      location: 'To Be Announced',
      description: 'Our premier international conference addressing systemic global challenges and building resilience strategies specifically for Global South nations. This landmark event will bring together heads of state, policy makers, researchers, and community leaders from across Africa, Asia, and Latin America to develop comprehensive frameworks for addressing interconnected global shocks including climate change, economic instability, health crises, and food insecurity.',
      type: 'Major Conference',
      attendees: '1000+ expected',
      image: 'https://readdy.ai/api/search-image?query=Large%20international%20conference%20venue%20with%20Global%20South%20delegates%20and%20speakers%20from%20Africa%20Asia%20Latin%20America%2C%20professional%20event%20setup%20with%20multiple%20screens%20and%20stage%2C%20diverse%20multicultural%20audience%2C%20high-resolution%20photography%20with%20excellent%20lighting&width=800&height=500&seq=global-south-conf&orientation=landscape',
      highlights: [
        'Heads of state and government ministers',
        'Leading researchers and academics',
        'Civil society and NGO leaders',
        'Private sector innovators',
        'Youth delegates from 50+ countries'
      ],
      themes: [
        'Climate Resilience in the Global South',
        'Economic Recovery and Inclusive Growth',
        'Health Systems Strengthening',
        'Food Security and Sustainable Agriculture',
        'Digital Transformation and Innovation'
      ]
    },
    {
      title: 'Cultural Resilience One Planet Conference (CROP) 2026',
      date: 'November 2026',
      location: 'Sydney, Australia',
      description: 'Exploring the vital role of cultural heritage and traditional knowledge in building community resilience and sustainable development. This unique conference brings together cultural practitioners, indigenous leaders, researchers, and policy makers to examine how cultural assets can strengthen community resilience against global shocks while preserving invaluable heritage for future generations.',
      type: 'Cultural Conference',
      attendees: '500+ expected',
      image: 'https://readdy.ai/api/search-image?query=Cultural%20conference%20with%20traditional%20elements%20from%20diverse%20cultures%2C%20indigenous%20leaders%20and%20cultural%20practitioners%2C%20modern%20conference%20facility%20with%20cultural%20decorations%2C%20professional%20event%20photography%20with%20vibrant%20colors&width=800&height=500&seq=cultural-conf&orientation=landscape',
      highlights: [
        'Indigenous knowledge keepers',
        'Cultural heritage experts',
        'UNESCO representatives',
        'Community resilience practitioners',
        'Artists and cultural innovators'
      ],
      themes: [
        'Traditional Knowledge and Climate Adaptation',
        'Cultural Heritage Preservation',
        'Indigenous-Led Conservation',
        'Arts and Community Healing',
        'Intergenerational Knowledge Transfer'
      ]
    },
    {
      title: 'Nordic East Africa Business Economic Cooperation (NEABEC) 2026',
      date: 'April 2026',
      location: 'Helsinki, Finland',
      description: 'A groundbreaking regional summit focusing on Fintech and Technology Transfer, Education, Business Trade & Investments between the Global North and Global South, with a specific focus on East Africa and the Nordic countries. This summit will facilitate partnerships, investment opportunities, and knowledge exchange between two dynamic regions.',
      type: 'Business Summit',
      attendees: '300+ expected',
      image: 'https://readdy.ai/api/search-image?query=Modern%20business%20conference%20in%20Helsinki%20Finland%20with%20Nordic%20and%20African%20business%20leaders%2C%20fintech%20and%20technology%20summit%2C%20professional%20business%20networking%20event%2C%20contemporary%20Scandinavian%20venue%2C%20high-quality%20business%20photography&width=800&height=500&seq=neabec-conf&orientation=landscape',
      highlights: [
        'Nordic business leaders and investors',
        'East African entrepreneurs and innovators',
        'Fintech and technology companies',
        'Government trade representatives',
        'Academic and research institutions'
      ],
      themes: [
        'Fintech Innovation and Financial Inclusion',
        'Technology Transfer and Capacity Building',
        'Education Partnerships',
        'Trade and Investment Opportunities',
        'Sustainable Business Practices'
      ]
    },
    {
      title: 'Global Shocks Global Resilience Conference 2026',
      date: 'September 2026',
      location: 'Canada (City TBA)',
      description: 'Building on the success of our Post-COVID conference series, this international conference will address the full spectrum of global shocks and develop comprehensive resilience strategies. The conference will feature intensive workshops, panel discussions, and strategic planning sessions focused on pandemic preparedness, climate adaptation, economic stability, and social cohesion.',
      type: 'International Conference',
      attendees: '500+ expected',
      image: 'https://readdy.ai/api/search-image?query=International%20conference%20in%20modern%20Canadian%20convention%20center%20with%20diverse%20global%20delegates%2C%20resilience%20and%20preparedness%20themes%2C%20professional%20conference%20setup%2C%20multicultural%20audience%2C%20high-resolution%20event%20photography&width=800&height=500&seq=resilience-conf&orientation=landscape',
      highlights: [
        'Global health experts',
        'Climate scientists and policy makers',
        'Economic resilience specialists',
        'Community development leaders',
        'International organization representatives'
      ],
      themes: [
        'Pandemic Preparedness and Response',
        'Climate Adaptation Strategies',
        'Economic Shock Absorption',
        'Social Cohesion and Community Resilience',
        'International Cooperation Frameworks'
      ]
    },
    {
      title: 'Youth Leadership Summit 2025',
      date: 'July 15-17, 2025',
      location: 'Toronto, Ontario, Canada',
      description: 'Annual gathering of young leaders from around the world to develop leadership skills, build networks, and create action plans for addressing global challenges. This summit provides intensive training, mentorship opportunities, and platforms for youth-led initiatives.',
      type: 'Youth Summit',
      attendees: '200+ expected',
      image: 'https://readdy.ai/api/search-image?query=Youth%20leadership%20summit%20with%20diverse%20young%20leaders%20from%20different%20countries%2C%20leadership%20training%20and%20workshops%2C%20inspiring%20conference%20atmosphere%2C%20young%20professionals%20networking%2C%20professional%20event%20photography&width=800&height=500&seq=youth-summit&orientation=landscape',
      highlights: [
        'Young leaders aged 18-35',
        'Mentors and established leaders',
        'Social entrepreneurs',
        'Policy advocates',
        'Community organizers'
      ],
      themes: [
        'Leadership Development',
        'Social Entrepreneurship',
        'Policy Advocacy',
        'Community Organizing',
        'Cross-Cultural Collaboration'
      ]
    },
    {
      title: 'Women\'s Economic Empowerment Forum 2025',
      date: 'October 8-10, 2025',
      location: 'Nairobi, Kenya',
      description: 'Celebrating and advancing women\'s economic empowerment across Africa and beyond. This forum brings together women entrepreneurs, business leaders, policy makers, and development practitioners to share success stories, address challenges, and create pathways for greater economic participation.',
      type: 'Regional Forum',
      attendees: '400+ expected',
      image: 'https://readdy.ai/api/search-image?query=Women%20economic%20empowerment%20forum%20with%20successful%20African%20women%20entrepreneurs%20and%20business%20leaders%2C%20professional%20conference%20in%20Nairobi%2C%20women%20in%20business%20networking%2C%20inspiring%20atmosphere%2C%20high-quality%20event%20photography&width=800&height=500&seq=women-forum&orientation=landscape',
      highlights: [
        'Women entrepreneurs and business owners',
        'Women in leadership positions',
        'Microfinance and investment experts',
        'Policy makers and advocates',
        'Development practitioners'
      ],
      themes: [
        'Access to Finance and Capital',
        'Business Skills and Mentorship',
        'Policy Advocacy for Women',
        'Technology and Digital Business',
        'Work-Life Balance and Support Systems'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-green-600 to-emerald-700">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url(https://readdy.ai/api/search-image?query=Exciting%20upcoming%20international%20conference%20with%20modern%20venue%20setup%2C%20anticipation%20and%20preparation%20for%20major%20event%2C%20professional%20event%20planning%2C%20inspiring%20conference%20atmosphere%2C%20high-resolution%20photography&width=1920&height=800&seq=upcoming-hero&orientation=landscape)`
          }}
        />
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Upcoming Events
          </h1>
          <p className="text-xl md:text-2xl text-white/90 max-w-4xl mx-auto leading-relaxed">
            Join us at our upcoming conferences, summits, and forums designed to advance global resilience and create lasting positive change.
          </p>
        </div>
      </section>

      {/* Events List */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">2025-2026 Event Calendar</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Mark your calendar for these transformative events bringing together global leaders, experts, and changemakers.
            </p>
          </div>

          <div className="space-y-16">
            {upcomingEvents.map((event, index) => (
              <div key={index} className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-shadow">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
                  <div>
                    <img
                      src={event.image}
                      alt={event.title}
                      className="w-full h-full object-cover min-h-[400px]"
                    />
                  </div>
                  <div className="p-10">
                    <div className="flex items-center flex-wrap gap-3 mb-4">
                      <span className="bg-green-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                        {event.type}
                      </span>
                      <span className="text-green-600 font-bold text-lg">{event.date}</span>
                    </div>
                    <h3 className="text-3xl font-bold text-gray-900 mb-4">{event.title}</h3>
                    <div className="flex items-center mb-4">
                      <i className="ri-map-pin-line w-5 h-5 flex items-center justify-center text-gray-600 mr-2"></i>
                      <span className="text-gray-600 font-medium">{event.location}</span>
                    </div>
                    <p className="text-lg text-gray-700 mb-6 leading-relaxed">{event.description}</p>
                    
                    <div className="flex items-center mb-6">
                      <i className="ri-team-line w-5 h-5 flex items-center justify-center text-green-600 mr-2"></i>
                      <span className="text-green-600 font-semibold">{event.attendees}</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      <div className="bg-white rounded-xl p-4">
                        <h4 className="font-bold text-gray-900 mb-3">Key Participants</h4>
                        <ul className="space-y-2">
                          {event.highlights.slice(0, 3).map((highlight, hIndex) => (
                            <li key={hIndex} className="flex items-start text-sm">
                              <i className="ri-user-star-line w-4 h-4 flex items-center justify-center text-green-600 mr-2 mt-0.5 flex-shrink-0"></i>
                              <span className="text-gray-700">{highlight}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="bg-white rounded-xl p-4">
                        <h4 className="font-bold text-gray-900 mb-3">Key Themes</h4>
                        <ul className="space-y-2">
                          {event.themes.slice(0, 3).map((theme, tIndex) => (
                            <li key={tIndex} className="flex items-start text-sm">
                              <i className="ri-lightbulb-line w-4 h-4 flex items-center justify-center text-green-600 mr-2 mt-0.5 flex-shrink-0"></i>
                              <span className="text-gray-700">{theme}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-4">
                      <a
                        href={`/events/register/${event.title.toLowerCase().replace(/\s+/g, '-')}`}
                        className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap text-center"
                      >
                        Register Interest
                      </a>
                      <a
                        href={`/events/details/${event.title.toLowerCase().replace(/\s+/g, '-')}`}
                        className="bg-white hover:bg-gray-100 text-green-600 border-2 border-green-600 px-6 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap text-center"
                      >
                        Learn More
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-green-600">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Stay Updated on Our Events
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Subscribe to receive early notifications about upcoming events, registration openings, and exclusive opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact"
              className="bg-white text-green-600 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
            >
              Subscribe to Updates
            </a>
            <a
              href="/events"
              className="bg-green-700 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-800 transition-colors cursor-pointer whitespace-nowrap"
            >
              View All Events
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

export default function WhitePapersPage() {
  const whitePapers = [
    {
      title: "Reimagining Global Shocks Response: A Framework for the Global South",
      subtitle: "Building Resilient Systems in an Era of Cascading Crises",
      authors: "LDII Research Team in collaboration with International Partners",
      date: "March 2024",
      pages: "68 pages",
      description: "This comprehensive white paper presents a transformative framework for how Global South nations can better prepare for, respond to, and recover from global shocks including pandemics, climate disasters, economic crises, and geopolitical disruptions. Drawing on lessons from COVID-19 and recent climate events, the paper argues for a paradigm shift from reactive crisis management to proactive resilience building. Key recommendations include establishing regional early warning systems, creating flexible financing mechanisms, strengthening local manufacturing capacity, and building robust social protection systems. The framework emphasizes South-South cooperation, indigenous knowledge integration, and community-led approaches as essential components of effective shock response.",
      image: "https://readdy.ai/api/search-image?query=global%20crisis%20response%20planning%20with%20diverse%20international%20leaders%20analyzing%20data%20and%20strategies%2C%20modern%20command%20center%2C%20collaborative%20problem-solving%20atmosphere&width=800&height=600&seq=wp1&orientation=landscape",
      downloadUrl: "#",
      tags: ["Global Shocks", "Resilience", "Crisis Management", "Global South"]
    },
    {
      title: "Climate Finance Architecture for Vulnerable Nations: Innovative Mechanisms and Equitable Access",
      subtitle: "Bridging the Gap Between Climate Ambition and Financial Reality",
      authors: "Dr. Elena Rodriguez, Dr. James Omondi, International Climate Finance Consortium",
      date: "February 2024",
      pages: "82 pages",
      description: "This white paper provides an in-depth analysis of the current climate finance landscape and proposes innovative mechanisms to ensure vulnerable nations receive adequate, accessible, and predictable funding for climate adaptation and mitigation. The paper examines barriers to accessing existing climate funds, including complex application processes, capacity constraints, and misalignment between donor priorities and recipient needs. It presents detailed case studies of successful financing models including parametric insurance, green bonds, debt-for-climate swaps, and blended finance approaches. The paper makes concrete recommendations for reforming the global climate finance architecture to prioritize the needs of the most vulnerable countries, ensure local ownership, and create sustainable long-term funding streams.",
      image: "https://readdy.ai/api/search-image?query=climate%20finance%20meeting%20with%20international%20delegates%20discussing%20funding%20mechanisms%2C%20charts%20showing%20financial%20flows%2C%20professional%20conference%20setting&width=800&height=600&seq=wp2&orientation=landscape",
      downloadUrl: "#",
      tags: ["Climate Finance", "Adaptation", "Vulnerable Nations", "Innovation"]
    },
    {
      title: "Digital Transformation in Rural Communities: A Roadmap for Inclusive Connectivity",
      subtitle: "Ensuring No One is Left Behind in the Digital Age",
      authors: "Dr. Priya Sharma, Dr. Robert Thompson, Global Digital Inclusion Alliance",
      date: "January 2024",
      pages: "74 pages",
      description: "This white paper addresses the persistent digital divide affecting rural communities worldwide and presents a comprehensive roadmap for achieving inclusive digital transformation. The paper examines multiple dimensions of digital inclusion including infrastructure deployment, affordability, digital literacy, relevant content, and enabling policy environments. It presents innovative solutions such as community networks, satellite connectivity, shared device programs, and locally relevant digital services. The paper emphasizes that digital inclusion is not merely about providing internet access but requires a holistic approach that addresses social, economic, and cultural factors. Detailed implementation guidelines are provided for governments, telecommunications companies, civil society organizations, and international development agencies.",
      image: "https://readdy.ai/api/search-image?query=rural%20community%20members%20accessing%20digital%20technology%20in%20modern%20community%20center%2C%20diverse%20people%20using%20computers%20and%20mobile%20devices%2C%20supportive%20learning%20environment&width=800&height=600&seq=wp3&orientation=landscape",
      downloadUrl: "#",
      tags: ["Digital Inclusion", "Rural Development", "Connectivity", "Technology Access"]
    },
    {
      title: "Transforming Food Systems for Sustainability and Equity: A Multi-Stakeholder Approach",
      subtitle: "From Farm to Fork: Building Resilient and Just Food Systems",
      authors: "Dr. Ahmed Hassan, Dr. Sophie Dubois, Global Food Systems Initiative",
      date: "December 2023",
      pages: "96 pages",
      description: "This white paper presents a comprehensive analysis of the challenges facing global food systems and proposes a transformative multi-stakeholder approach to achieving sustainability and equity. The paper examines the complex interconnections between agricultural practices, climate change, nutrition, economic viability, biodiversity, and social justice. It argues that incremental improvements are insufficient and calls for fundamental transformation of how food is produced, distributed, and consumed. The paper presents detailed recommendations for transitioning to agroecological farming practices, reducing food waste, ensuring fair prices for farmers, improving nutrition outcomes, and building climate-resilient food systems. Special attention is given to the roles of smallholder farmers, women, indigenous communities, and youth in driving food system transformation.",
      image: "https://readdy.ai/api/search-image?query=sustainable%20food%20systems%20with%20farmers%2C%20distributors%2C%20and%20consumers%20collaborating%2C%20fresh%20produce%2C%20modern%20agricultural%20technology%2C%20farm-to-table%20concept&width=800&height=600&seq=wp4&orientation=landscape",
      downloadUrl: "#",
      tags: ["Food Systems", "Sustainability", "Agriculture", "Food Security"]
    },
    {
      title: "Strengthening Health Systems in Post-Pandemic Era: Lessons and Strategic Directions",
      subtitle: "Building Back Better: From Crisis Response to Resilient Health Systems",
      authors: "Dr. Amina Yusuf, Dr. Thomas Anderson, Global Health Resilience Network",
      date: "November 2023",
      pages: "88 pages",
      description: "This white paper synthesizes critical lessons from the COVID-19 pandemic and provides strategic directions for strengthening health systems worldwide. The paper examines how the pandemic exposed fundamental weaknesses in health systems including inadequate infrastructure, health worker shortages, supply chain vulnerabilities, weak surveillance systems, and inequitable access to care. It presents a comprehensive framework for building resilient health systems that can withstand future shocks while providing quality universal health coverage. Key recommendations include investing in primary health care, strengthening community health worker programs, building local manufacturing capacity for essential medicines and supplies, establishing robust disease surveillance systems, and ensuring sustainable health financing. The paper emphasizes that health system strengthening must be grounded in principles of equity, quality, and community participation.",
      image: "https://readdy.ai/api/search-image?query=modern%20healthcare%20facility%20with%20diverse%20medical%20professionals%20providing%20quality%20care%2C%20advanced%20medical%20equipment%2C%20patient-centered%20environment&width=800&height=600&seq=wp5&orientation=landscape",
      downloadUrl: "#",
      tags: ["Health Systems", "Pandemic Response", "Universal Health Coverage", "Resilience"]
    },
    {
      title: "Women's Economic Empowerment: Breaking Barriers and Building Pathways to Prosperity",
      subtitle: "From Marginalization to Leadership: Transforming Economic Opportunities for Women",
      authors: "Dr. Grace Mwangi, Dr. Isabella Romano, Women's Economic Empowerment Coalition",
      date: "October 2023",
      pages: "78 pages",
      description: "This white paper provides a comprehensive analysis of barriers to women's economic empowerment and presents evidence-based strategies for creating transformative change. The paper examines multiple dimensions including access to finance, property rights, education and skills development, entrepreneurship support, workplace equality, and unpaid care work. It presents compelling evidence that women's economic empowerment is not only a matter of justice and rights but also a critical driver of economic growth, poverty reduction, and sustainable development. The paper features inspiring case studies of successful interventions from diverse contexts and provides detailed recommendations for policymakers, private sector actors, civil society organizations, and international development agencies. Special attention is given to intersectional approaches that address how gender intersects with other forms of marginalization.",
      image: "https://readdy.ai/api/search-image?query=diverse%20women%20entrepreneurs%20and%20business%20leaders%20in%20professional%20setting%2C%20women-led%20businesses%2C%20economic%20empowerment%2C%20collaborative%20workspace&width=800&height=600&seq=wp6&orientation=landscape",
      downloadUrl: "#",
      tags: ["Women's Empowerment", "Economic Development", "Gender Equality", "Entrepreneurship"]
    },
    {
      title: "Youth Empowerment in the 21st Century: Holistic Approaches to Mental Health and Economic Opportunity",
      subtitle: "Investing in Youth: Building Foundations for Thriving Communities",
      authors: "Dr. Jennifer Lee, Dr. Marcus Williams, Youth Development Research Consortium",
      date: "September 2023",
      pages: "72 pages",
      description: "This white paper presents a holistic framework for youth empowerment that integrates mental health support, skills development, employment opportunities, and civic engagement. The paper examines the unique challenges facing today's youth including mental health crises, unemployment, educational disruptions, and social isolation. It argues that fragmented, single-issue approaches are insufficient and calls for integrated programs that address the multiple dimensions of youth wellbeing and development. The paper presents detailed evidence on effective interventions including peer support programs, mentorship initiatives, skills training, entrepreneurship support, and youth-led community projects. Special attention is given to reaching marginalized youth including those affected by poverty, violence, discrimination, and displacement. The paper provides practical implementation guidelines for youth-serving organizations, educational institutions, employers, and policymakers.",
      image: "https://readdy.ai/api/search-image?query=diverse%20youth%20group%20participating%20in%20empowerment%20programs%2C%20mentorship%20activities%2C%20skills%20training%2C%20positive%20supportive%20environment&width=800&height=600&seq=wp7&orientation=landscape",
      downloadUrl: "#",
      tags: ["Youth Development", "Mental Health", "Employment", "Empowerment"]
    },
    {
      title: "Poverty Eradication Through Inclusive Economic Growth: Policy Frameworks and Implementation Strategies",
      subtitle: "Leaving No One Behind: Pathways to Shared Prosperity",
      authors: "Dr. David Osei, Dr. Anna Kowalski, Inclusive Growth Policy Network",
      date: "August 2023",
      pages: "92 pages",
      description: "This white paper examines successful approaches to poverty eradication through inclusive economic growth and provides detailed policy frameworks and implementation strategies. The paper argues that economic growth alone is insufficient for poverty eradication and that deliberate policies and programs are needed to ensure that growth benefits reach the poorest and most marginalized populations. It analyzes successful case studies from diverse contexts including social protection systems, progressive taxation, public investment in education and health, land reform, and support for small and medium enterprises. The paper presents a comprehensive policy framework that addresses multiple dimensions of poverty including income, education, health, housing, and social inclusion. Detailed implementation guidance is provided for governments, international organizations, civil society, and private sector actors. The paper emphasizes the importance of participatory approaches that give voice and agency to people living in poverty.",
      image: "https://readdy.ai/api/search-image?query=poverty%20eradication%20programs%20with%20diverse%20community%20members%20receiving%20support%20and%20training%2C%20economic%20empowerment%20activities%2C%20hopeful%20atmosphere&width=800&height=600&seq=wp8&orientation=landscape",
      downloadUrl: "#",
      tags: ["Poverty Eradication", "Inclusive Growth", "Economic Policy", "Social Protection"]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section id="hero" className="relative min-h-[60vh] flex items-center justify-center bg-gradient-to-br from-green-600 via-emerald-700 to-green-800 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url(https://readdy.ai/api/search-image?query=White%20papers%20and%20research%20reports%2C%20professional%20research%20environment%2C%20policy%20documents%2C%20professional%20photography&width=1920&height=1080&seq=whitepaper-hero&orientation=landscape)`
          }}
        ></div>
        <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">White Papers</h1>
          <p className="text-xl md:text-2xl text-green-100 max-w-3xl">
            In-depth policy analysis and strategic frameworks addressing critical global development challenges
          </p>
        </div>
      </section>

      {/* White Papers List */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="space-y-12">
            {whitePapers.map((paper, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow duration-300">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Image */}
                  <div className={`lg:col-span-1 ${index % 2 === 0 ? 'lg:order-1' : 'lg:order-2'}`}>
                    <img
                      src={paper.image}
                      alt={paper.title}
                      className="w-full h-full object-cover object-top min-h-[350px]"
                    />
                  </div>

                  {/* Content */}
                  <div className={`lg:col-span-2 p-8 ${index % 2 === 0 ? 'lg:order-2' : 'lg:order-1'}`}>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {paper.tags.map((tag, tagIndex) => (
                        <span
                          key={tagIndex}
                          className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                      {paper.title}
                    </h2>
                    
                    <h3 className="text-lg text-green-600 font-semibold mb-4">
                      {paper.subtitle}
                    </h3>

                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-4">
                      <span className="flex items-center">
                        <i className="ri-user-line w-4 h-4 flex items-center justify-center mr-1"></i>
                        {paper.authors}
                      </span>
                      <span className="flex items-center">
                        <i className="ri-calendar-line w-4 h-4 flex items-center justify-center mr-1"></i>
                        {paper.date}
                      </span>
                      <span className="flex items-center">
                        <i className="ri-file-text-line w-4 h-4 flex items-center justify-center mr-1"></i>
                        {paper.pages}
                      </span>
                    </div>

                    <p className="text-gray-700 leading-relaxed mb-6">
                      {paper.description}
                    </p>

                    <div className="flex flex-wrap gap-4">
                      <a
                        href={paper.downloadUrl}
                        className="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-download-line w-5 h-5 flex items-center justify-center mr-2"></i>
                        Download White Paper
                      </a>
                      <button className="inline-flex items-center px-6 py-3 border-2 border-green-600 text-green-600 hover:bg-green-50 font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap">
                        <i className="ri-share-line w-5 h-5 flex items-center justify-center mr-2"></i>
                        Share
                      </button>
                      <button className="inline-flex items-center px-6 py-3 border-2 border-gray-300 text-gray-700 hover:bg-gray-50 font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap">
                        <i className="ri-bookmark-line w-5 h-5 flex items-center justify-center mr-2"></i>
                        Save for Later
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section 
        className="py-20 bg-gradient-to-br from-green-600 to-emerald-700 relative overflow-hidden"
      >
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url(https://readdy.ai/api/search-image?query=Research%20and%20policy%20analysis%2C%20professional%20research%20environment%2C%20white%20papers%20and%20reports%2C%20professional%20photography&width=1920&height=800&seq=whitepaper-cta&orientation=landscape)`
          }}
        />
        <div className="absolute inset-0 bg-green-900/80"></div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Commission Custom Research</h2>
          <p className="text-xl text-white/90 mb-8">
            Need specialized research or policy analysis for your organization? Our research team can develop custom white papers tailored to your specific needs.
          </p>
          <a
            href="/contact"
            className="relative z-20 inline-block bg-white text-green-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            Contact Research Team
          </a>
        </div>
      </section>
    </div>
  );
}

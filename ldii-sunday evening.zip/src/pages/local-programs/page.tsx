
import { useState } from 'react';

export default function LocalProgramsPage() {
  const [expandedSections, setExpandedSections] = useState<{ [key: string]: boolean }>({});

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const youthPrograms = [
    {
      id: 'mental-health',
      title: 'Mental Health Awareness & Support',
      description: 'Providing accessible mental health resources, counseling services, and peer support networks to help youth navigate emotional and psychological challenges. Our comprehensive approach includes individual therapy, group counseling, crisis intervention, and preventive mental health education to build resilience and emotional well-being.',
      image: 'https://readdy.ai/api/search-image?query=Diverse%20Canadian%20youth%20in%20supportive%20group%20therapy%20session%2C%20mental%20health%20counseling%2C%20professional%20therapist%20leading%20discussion%2C%20warm%20welcoming%20environment%2C%20multicultural%20participants%2C%20professional%20photography%20with%20natural%20lighting&width=600&height=400&seq=mental-health-youth&orientation=landscape',
      services: [
        'Individual and group counseling sessions',
        'Mental health awareness workshops',
        'Crisis intervention and support hotlines',
        'Peer mentorship programs',
        'Stress management and coping strategies'
      ]
    },
    {
      id: 'violence-prevention',
      title: 'Gun Violence & Gang Prevention',
      description: 'Evidence-based intervention and prevention strategies to protect youth from violence and gang involvement. Through community outreach, education, and creating safe spaces, we provide alternatives to violence and help young people build positive futures. Our programs address root causes while offering immediate support and protection.',
      image: 'https://readdy.ai/api/search-image?query=Youth%20community%20outreach%20program%20in%20Toronto%20neighborhood%2C%20diverse%20young%20people%20participating%20in%20positive%20activities%2C%20community%20center%20setting%2C%20mentors%20engaging%20with%20youth%2C%20professional%20photography%20with%20hopeful%20atmosphere&width=600&height=400&seq=violence-prevention&orientation=landscape',
      services: [
        'Community outreach and education programs',
        'Conflict resolution and mediation training',
        'Safe space creation and youth centers',
        'Family support and counseling',
        'Alternative activities and positive engagement'
      ]
    },
    {
      id: 'employment-readiness',
      title: 'Employment Readiness & Career Development',
      description: 'Equipping youth with the skills, knowledge, and connections needed to succeed in the modern workforce. Our comprehensive career development program includes resume building, interview preparation, job placement assistance, and ongoing career counseling to ensure long-term success in the Canadian job market.',
      image: 'https://readdy.ai/api/search-image?query=Young%20professionals%20in%20job%20interview%20preparation%20workshop%2C%20career%20counseling%20session%2C%20diverse%20Canadian%20youth%20learning%20employment%20skills%2C%20modern%20training%20facility%2C%20professional%20photography%20with%20bright%20lighting&width=600&height=400&seq=employment-youth&orientation=landscape',
      services: [
        'Resume writing and interview preparation',
        'Job search assistance and placement',
        'Career counseling and pathway planning',
        'Professional networking opportunities',
        'Workplace readiness training'
      ]
    },
    {
      id: 'skills-building',
      title: 'Skills Building Workshops',
      description: 'Comprehensive training programs to develop essential life and professional skills for success in the 21st century. From digital literacy to financial management, our workshops provide practical knowledge that empowers youth to navigate modern challenges and seize opportunities for personal and professional growth.',
      image: 'https://readdy.ai/api/search-image?query=Youth%20participating%20in%20digital%20skills%20workshop%2C%20computer%20training%20session%2C%20diverse%20young%20people%20learning%20technology%2C%20modern%20classroom%20setting%2C%20professional%20photography%20with%20engaging%20atmosphere&width=600&height=400&seq=skills-workshop&orientation=landscape',
      services: [
        'Digital literacy and technology training',
        'Financial literacy and money management',
        'Leadership development programs',
        'Communication and public speaking',
        'Entrepreneurship and business basics'
      ]
    },
    {
      id: 'arts-culture',
      title: 'Arts & Cultural Expression',
      description: 'Fostering creativity and cultural identity through arts programs that provide youth with platforms for self-expression and community engagement. Our arts initiatives include music, visual arts, dance, and theater programs that build confidence, develop talents, and celebrate diverse cultural backgrounds while creating pathways to creative careers.',
      image: 'https://readdy.ai/api/search-image?query=Diverse%20youth%20participating%20in%20arts%20and%20culture%20program%2C%20creative%20workshop%20with%20painting%20and%20music%2C%20multicultural%20expression%2C%20community%20arts%20center%2C%20professional%20photography%20with%20vibrant%20colors&width=600&height=400&seq=arts-culture-youth&orientation=landscape',
      services: [
        'Music and performing arts programs',
        'Visual arts and creative workshops',
        'Cultural celebration events',
        'Arts mentorship and career guidance',
        'Community art projects and exhibitions'
      ]
    },
    {
      id: 'sports-recreation',
      title: 'Sports & Recreation Programs',
      description: 'Promoting physical health, teamwork, and leadership through organized sports and recreational activities. Our programs provide safe, structured environments where youth can develop athletic skills, build friendships, and learn valuable life lessons about discipline, perseverance, and collaboration while staying active and healthy.',
      image: 'https://readdy.ai/api/search-image?query=Diverse%20Canadian%20youth%20playing%20basketball%20in%20community%20sports%20program%2C%20team%20activities%2C%20recreational%20facility%2C%20coaches%20mentoring%20young%20athletes%2C%20professional%20photography%20with%20dynamic%20action&width=600&height=400&seq=sports-youth&orientation=landscape',
      services: [
        'Team sports leagues and tournaments',
        'Individual fitness and wellness programs',
        'Outdoor adventure activities',
        'Sports leadership and coaching training',
        'Health and nutrition education'
      ]
    },
    {
      id: 'academic-support',
      title: 'Academic Support & Tutoring',
      description: 'Providing comprehensive academic assistance to help youth excel in their studies and achieve their educational goals. Our tutoring programs offer personalized support in core subjects, homework help, exam preparation, and study skills development, ensuring every student has the resources they need to succeed academically.',
      image: 'https://readdy.ai/api/search-image?query=Youth%20tutoring%20session%20in%20library%2C%20diverse%20students%20receiving%20academic%20support%2C%20one-on-one%20mentoring%2C%20study%20group%20environment%2C%20professional%20photography%20with%20focused%20atmosphere&width=600&height=400&seq=academic-support&orientation=landscape',
      services: [
        'One-on-one tutoring in core subjects',
        'Homework help and study groups',
        'Exam preparation and test-taking strategies',
        'College and university application support',
        'Scholarship and bursary assistance'
      ]
    },
    {
      id: 'music-performing-arts',
      title: 'Music & Performing Arts',
      description: 'Empowering youth through comprehensive music education and performing arts training. Our program offers instruction in various musical instruments including piano, guitar, drums, violin, and brass instruments, alongside vocal training and singing lessons. Students learn music theory, performance techniques, and stage presence while developing discipline, creativity, and self-expression. We provide opportunities for solo and ensemble performances, recording sessions, and participation in community concerts and cultural events.',
      image: 'https://readdy.ai/api/search-image?query=Diverse%20Canadian%20youth%20learning%20musical%20instruments%20in%20music%20class%2C%20young%20people%20playing%20piano%20guitar%20drums%20violin%2C%20singing%20lessons%20vocal%20training%2C%20music%20teacher%20instructing%20students%2C%20modern%20music%20studio%2C%20professional%20photography%20with%20inspiring%20atmosphere&width=600&height=400&seq=music-performing-arts&orientation=landscape',
      services: [
        'Instrumental music lessons (piano, guitar, drums, violin, brass)',
        'Vocal training and singing lessons',
        'Music theory and composition',
        'Performance opportunities and recitals',
        'Recording studio access and production basics',
        'Ensemble and band participation',
        'Stage presence and performance coaching'
      ]
    },
    {
      id: 'media-filmmaking',
      title: 'Media, Videography & Filmmaking',
      description: 'Comprehensive training in modern media production, videography, and filmmaking for aspiring content creators and filmmakers. Youth learn professional video production techniques, cinematography, editing, storytelling, and digital media creation. Our program covers everything from pre-production planning and scriptwriting to shooting techniques, post-production editing, and distribution. Students gain hands-on experience with industry-standard equipment and software, preparing them for careers in film, television, digital media, and entertainment industries.',
      image: 'https://readdy.ai/api/search-image?query=Diverse%20Canadian%20youth%20learning%20filmmaking%20and%20videography%2C%20young%20people%20operating%20professional%20cameras%20and%20video%20equipment%2C%20film%20production%20class%2C%20video%20editing%20on%20computers%2C%20media%20students%20creating%20content%2C%20modern%20media%20lab%2C%20professional%20photography%20with%20creative%20atmosphere&width=600&height=400&seq=media-filmmaking&orientation=landscape',
      services: [
        'Video production and cinematography training',
        'Film editing and post-production techniques',
        'Scriptwriting and storyboarding',
        'Camera operation and lighting techniques',
        'Sound recording and audio production',
        'Digital media content creation',
        'Documentary and narrative filmmaking',
        'YouTube and social media content creation',
        'Industry networking and career pathways'
      ]
    }
  ];

  const newcomerPrograms = [
    {
      id: 'settlement-services',
      title: 'Settlement Services',
      description: 'Comprehensive support to help newcomers establish themselves in their new community and navigate the complexities of settling in Canada. From finding housing to understanding government services, we provide the guidance and resources needed for a successful transition to life in Ontario.',
      image: 'https://readdy.ai/api/search-image?query=Newcomer%20family%20receiving%20settlement%20services%20in%20Canada%2C%20diverse%20immigrants%20meeting%20with%20settlement%20worker%2C%20welcoming%20office%20environment%2C%20professional%20photography%20with%20warm%20atmosphere&width=600&height=400&seq=settlement-services&orientation=landscape',
      services: [
        'Housing search and rental assistance',
        'Government services navigation',
        'Community orientation and tours',
        'Documentation and legal support',
        'Family reunification assistance'
      ]
    },
    {
      id: 'language-support',
      title: 'Language Support',
      description: 'English and French language training to facilitate communication and integration into Canadian society. Our language programs are designed for all proficiency levels, from beginners to advanced learners, with a focus on practical communication skills for everyday life, work, and community engagement.',
      image: 'https://readdy.ai/api/search-image?query=ESL%20English%20language%20class%20for%20newcomers%20in%20Canada%2C%20diverse%20adult%20students%20learning%20English%2C%20professional%20teacher%20leading%20lesson%2C%20modern%20classroom%20setting%2C%20professional%20photography&width=600&height=400&seq=language-support&orientation=landscape',
      services: [
        'ESL/FSL classes at multiple levels',
        'Conversation practice groups',
        'Language assessment and placement',
        'Workplace language training',
        'Cultural communication workshops'
      ]
    },
    {
      id: 'cultural-orientation',
      title: 'Cultural Orientation',
      description: 'Understanding Canadian culture, values, and social norms for successful integration and meaningful participation in community life. Our cultural orientation programs help newcomers navigate cultural differences, understand Canadian customs, and build bridges between their heritage and their new home.',
      image: 'https://readdy.ai/api/search-image?query=Newcomers%20participating%20in%20Canadian%20cultural%20orientation%20workshop%2C%20diverse%20immigrants%20learning%20about%20Canadian%20culture%2C%20multicultural%20celebration%2C%20community%20center%2C%20professional%20photography&width=600&height=400&seq=cultural-orientation&orientation=landscape',
      services: [
        'Canadian culture and customs workshops',
        'Rights and responsibilities education',
        'Social etiquette and norms training',
        'Cultural celebration events',
        'Cross-cultural communication skills'
      ]
    },
    {
      id: 'employment-training',
      title: 'Employment Training',
      description: 'Preparing newcomers for the Canadian job market and career success through comprehensive employment services. We help newcomers leverage their international experience and credentials while developing the skills and knowledge needed to thrive in Ontario\'s diverse economy.',
      image: 'https://readdy.ai/api/search-image?query=Newcomers%20in%20job%20training%20workshop%20in%20Canada%2C%20diverse%20immigrants%20learning%20Canadian%20workplace%20culture%2C%20professional%20development%20session%2C%20modern%20training%20facility%2C%20professional%20photography&width=600&height=400&seq=employment-training&orientation=landscape',
      services: [
        'Credential recognition assistance',
        'Canadian workplace culture training',
        'Skills assessment and upgrading',
        'Job search strategies and networking',
        'Mentorship and career coaching'
      ]
    },
    {
      id: 'health-wellness',
      title: 'Health & Wellness Services',
      description: 'Connecting newcomers with essential healthcare services and promoting physical and mental wellness during the settlement process. We help navigate the Canadian healthcare system, access medical services, and understand health insurance options while providing culturally sensitive health education and wellness programs.',
      image: 'https://readdy.ai/api/search-image?query=Newcomers%20receiving%20health%20services%20orientation%20in%20Canada%2C%20diverse%20immigrants%20learning%20about%20Canadian%20healthcare%20system%2C%20health%20information%20session%2C%20medical%20clinic%20setting%2C%20professional%20photography%20with%20caring%20atmosphere&width=600&height=400&seq=health-wellness-newcomers&orientation=landscape',
      services: [
        'Healthcare system navigation and orientation',
        'Health insurance enrollment assistance',
        'Medical appointment booking and interpretation',
        'Mental health support and counseling',
        'Wellness workshops and health education',
        'Connection to family doctors and specialists',
        'Preventive health screening programs'
      ]
    },
    {
      id: 'youth-family-programs',
      title: 'Youth & Family Integration Programs',
      description: 'Supporting newcomer families and youth in their transition to Canadian life through specialized programs that address the unique challenges faced by children and families. We provide educational support, recreational activities, parenting workshops, and family counseling to ensure successful integration for all family members.',
      image: 'https://readdy.ai/api/search-image?query=Newcomer%20families%20with%20children%20participating%20in%20integration%20program%2C%20diverse%20immigrant%20youth%20and%20parents%20in%20family%20activities%2C%20community%20center%20programs%2C%20multicultural%20family%20support%2C%20professional%20photography%20with%20welcoming%20atmosphere&width=600&height=400&seq=youth-family-integration&orientation=landscape',
      services: [
        'School enrollment and educational support',
        'Youth mentorship and tutoring programs',
        'Parenting workshops and family counseling',
        'Recreational and cultural activities for families',
        'Childcare information and resources',
        'Youth leadership and skill development',
        'Family reunification support services'
      ]
    }
  ];

  const businessPrograms = [
    {
      id: 'entrepreneur-connections',
      title: 'Entrepreneur Connections',
      description: 'Building meaningful relationships between business owners and aspiring entrepreneurs through structured networking events and platforms. Our connection programs create opportunities for collaboration, knowledge sharing, and business development in a supportive community of like-minded professionals.',
      image: 'https://readdy.ai/api/search-image?query=Business%20networking%20event%20in%20Toronto%2C%20diverse%20entrepreneurs%20connecting%2C%20professional%20business%20meeting%2C%20modern%20conference%20venue%2C%20professional%20photography%20with%20dynamic%20atmosphere&width=600&height=400&seq=entrepreneur-connections&orientation=landscape',
      services: [
        'Monthly networking events and mixers',
        'Industry-specific meetups',
        'Speed networking sessions',
        'Online networking platform access',
        'Business partnership facilitation'
      ]
    },
    {
      id: 'mentorship-programs',
      title: 'Mentorship Programs',
      description: 'Pairing experienced business leaders with emerging entrepreneurs for guidance and support in building successful enterprises. Our mentorship programs provide invaluable insights, accountability, and encouragement from those who have navigated the challenges of entrepreneurship.',
      image: 'https://readdy.ai/api/search-image?query=Business%20mentor%20meeting%20with%20entrepreneur%2C%20professional%20mentorship%20session%2C%20diverse%20business%20leaders%2C%20modern%20office%20setting%2C%20professional%20photography%20with%20collaborative%20atmosphere&width=600&height=400&seq=business-mentorship&orientation=landscape',
      services: [
        'One-on-one mentorship matching',
        'Group mentoring circles',
        'Expert advisory sessions',
        'Peer learning groups',
        'Success story sharing events'
      ]
    },
    {
      id: 'small-business-support',
      title: 'Small Business Support',
      description: 'Providing resources and assistance to help small businesses thrive in competitive markets. From business planning to financial management, we offer comprehensive support services that address the unique challenges faced by small business owners in Ontario.',
      image: 'https://readdy.ai/api/search-image?query=Small%20business%20owner%20receiving%20business%20support%20consultation%2C%20diverse%20entrepreneurs%20in%20planning%20session%2C%20professional%20business%20advisor%2C%20modern%20office%2C%20professional%20photography&width=600&height=400&seq=small-business-support&orientation=landscape',
      services: [
        'Business plan development workshops',
        'Financial management training',
        'Marketing and branding support',
        'Access to funding opportunities',
        'Legal and regulatory guidance'
      ]
    },
    {
      id: 'professional-development',
      title: 'Professional Development',
      description: 'Continuous learning opportunities to enhance business skills and knowledge in an ever-evolving marketplace. Our professional development programs keep entrepreneurs and business professionals at the forefront of industry trends, technologies, and best practices.',
      image: 'https://readdy.ai/api/search-image?query=Business%20professionals%20in%20professional%20development%20workshop%2C%20diverse%20entrepreneurs%20learning%20new%20skills%2C%20modern%20training%20facility%2C%20professional%20photography%20with%20engaged%20participants&width=600&height=400&seq=professional-development&orientation=landscape',
      services: [
        'Leadership and management training',
        'Digital marketing workshops',
        'Sales and customer service excellence',
        'Innovation and technology adoption',
        'Industry trends and insights sessions'
      ]
    },
    {
      id: 'startup-incubator',
      title: 'Startup Incubator & Accelerator',
      description: 'Intensive support program for early-stage startups and innovative business ideas. Our incubator provides workspace, mentorship, funding connections, and comprehensive business development resources to help entrepreneurs transform their ideas into successful, scalable businesses. We offer structured programming, access to investors, and a collaborative community of fellow entrepreneurs.',
      image: 'https://readdy.ai/api/search-image?query=Startup%20entrepreneurs%20in%20business%20incubator%20workspace%2C%20diverse%20founders%20working%20on%20innovative%20projects%2C%20modern%20coworking%20space%2C%20pitch%20presentations%2C%20professional%20photography%20with%20entrepreneurial%20energy&width=600&height=400&seq=startup-incubator&orientation=landscape',
      services: [
        'Coworking space and office facilities',
        'Business model development and validation',
        'Pitch preparation and investor connections',
        'Technology and product development support',
        'Market research and competitive analysis',
        'Funding strategy and grant applications',
        'Legal and intellectual property guidance',
        'Go-to-market strategy development'
      ]
    },
    {
      id: 'export-trade-development',
      title: 'Export & Trade Development',
      description: 'Supporting Ontario businesses in expanding into international markets through export readiness training, trade mission participation, and global market intelligence. We help businesses navigate international trade regulations, identify export opportunities, develop market entry strategies, and connect with international buyers and distributors to grow their global presence.',
      image: 'https://readdy.ai/api/search-image?query=Business%20professionals%20at%20international%20trade%20conference%2C%20diverse%20entrepreneurs%20exploring%20export%20opportunities%2C%20global%20business%20meeting%2C%20trade%20show%20exhibition%2C%20professional%20photography%20with%20international%20business%20atmosphere&width=600&height=400&seq=export-trade-development&orientation=landscape',
      services: [
        'Export readiness assessment and training',
        'International market research and analysis',
        'Trade mission and delegation participation',
        'Customs and regulatory compliance guidance',
        'International buyer and distributor connections',
        'Export financing and insurance information',
        'Cross-cultural business communication training',
        'Global supply chain development'
      ]
    }
  ];

  const offices = [
    {
      name: 'Toronto Office',
      address: '3701 Chesswood Drive, Unit 315',
      city: 'Toronto, Ontario M3J 2P6',
      phone: '+1 (416) 660-4233',
      email: 'info@ldiinitiatives.org',
      hours: 'Monday - Friday: 9:00 AM - 5:00 PM',
      icon: 'ri-building-line',
      mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2882.5!2d-79.4678!3d43.7532!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDPCsDQ1JzExLjUiTiA3OcKwMjgnMDQuMSJX!5e0!3m2!1sen!2sca!4v1234567890'
    },
    {
      name: 'Brampton Office',
      address: '101 West Dr C',
      city: 'Brampton, ON L6T 2J6',
      phone: '+1 (416) 660-4233',
      email: 'info@ldiinitiatives.org',
      hours: 'Monday - Friday: 9:00 AM - 5:00 PM',
      icon: 'ri-building-2-line',
      mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2882.5!2d-79.7623!3d43.7321!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDPCsDQzJzU1LjYiTiA3OcKwNDUnNDQuMyJX!5e0!3m2!1sen!2sca!4v1234567891'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-24 bg-gradient-to-br from-green-600 to-emerald-700">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url(https://readdy.ai/api/search-image?query=Diverse%20Canadian%20youth%20and%20newcomers%20participating%20in%20community%20programs%2C%20Toronto%20cityscape%20background%2C%20multicultural%20community%20engagement%2C%20professional%20photography%20with%20vibrant%20atmosphere%20and%20hopeful%20expressions&width=1920&height=800&seq=local-programs-hero&orientation=landscape)`
          }}
        />
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Local Programs
          </h1>
          <p className="text-xl md:text-2xl text-white/90 max-w-4xl mx-auto leading-relaxed">
            Empowering communities across Canada and Ontario through comprehensive support programs for youth, newcomers, and entrepreneurs.
          </p>
        </div>
      </section>

      {/* Sticky Navigation Menu */}
      <div className="sticky top-16 lg:top-20 z-40 bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-center space-x-2 overflow-x-auto py-4">
            <button
              onClick={() => scrollToSection('youth-empowerment')}
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap text-sm font-medium"
            >
              Youth Empowerment
            </button>
            <button
              onClick={() => scrollToSection('empowering-newcomers')}
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap text-sm font-medium"
            >
              Empowering Newcomers
            </button>
            <button
              onClick={() => scrollToSection('business-networking')}
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap text-sm font-medium"
            >
              Business Networking
            </button>
            <button
              onClick={() => scrollToSection('office-locations')}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors cursor-pointer whitespace-nowrap text-sm font-medium"
            >
              Our Locations
            </button>
          </div>
        </div>
      </div>

      {/* Youth Empowerment Initiative */}
      <section id="youth-empowerment" className="py-20 bg-white scroll-mt-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-block bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl px-8 py-4 mb-6">
              <h2 className="text-4xl font-bold text-white">Youth Empowerment Initiative</h2>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive programs supporting Canadian and Ontario youth through critical life challenges
            </p>
          </div>

          <div className="space-y-16">
            {youthPrograms.map((program, index) => (
              <div key={program.id} className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-8 items-center`}>
                <div className="lg:w-1/2">
                  <img
                    src={program.image}
                    alt={program.title}
                    className="w-full h-80 object-cover rounded-2xl shadow-lg"
                  />
                </div>
                <div className="lg:w-1/2">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">{program.title}</h3>
                  <div className="mb-4">
                    <p className={`text-gray-700 leading-relaxed ${!expandedSections[program.id] && program.description.length > 200 ? 'line-clamp-3' : ''}`}>
                      {program.description}
                    </p>
                    {program.description.length > 200 && (
                      <button
                        onClick={() => toggleSection(program.id)}
                        className="text-green-600 hover:text-green-700 font-medium mt-2 cursor-pointer"
                      >
                        {expandedSections[program.id] ? 'Read Less' : 'Read More'}
                      </button>
                    )}
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold text-gray-900 mb-3">Services Offered:</h4>
                    <ul className="space-y-2">
                      {program.services.map((service, serviceIndex) => (
                        <li key={serviceIndex} className="flex items-start space-x-2">
                          <i className="ri-check-line w-5 h-5 flex items-center justify-center text-green-600 flex-shrink-0 mt-0.5"></i>
                          <span className="text-gray-700">{service}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Empowering Newcomers */}
      <section id="empowering-newcomers" className="py-20 bg-gray-50 scroll-mt-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-block bg-gradient-to-r from-green-500 to-green-600 rounded-2xl px-8 py-4 mb-6">
              <h2 className="text-4xl font-bold text-white">Empowering Newcomers</h2>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Supporting newcomers to successfully integrate into Canadian society
            </p>
          </div>

          <div className="space-y-16">
            {newcomerPrograms.map((program, index) => (
              <div key={program.id} className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-8 items-center`}>
                <div className="lg:w-1/2">
                  <img
                    src={program.image}
                    alt={program.title}
                    className="w-full h-80 object-cover rounded-2xl shadow-lg"
                  />
                </div>
                <div className="lg:w-1/2">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">{program.title}</h3>
                  <div className="mb-4">
                    <p className={`text-gray-700 leading-relaxed ${!expandedSections[program.id] && program.description.length > 200 ? 'line-clamp-3' : ''}`}>
                      {program.description}
                    </p>
                    {program.description.length > 200 && (
                      <button
                        onClick={() => toggleSection(program.id)}
                        className="text-green-600 hover:text-green-700 font-medium mt-2 cursor-pointer"
                      >
                        {expandedSections[program.id] ? 'Read Less' : 'Read More'}
                      </button>
                    )}
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <h4 className="font-semibold text-gray-900 mb-3">Services Offered:</h4>
                    <ul className="space-y-2">
                      {program.services.map((service, serviceIndex) => (
                        <li key={serviceIndex} className="flex items-start space-x-2">
                          <i className="ri-check-line w-5 h-5 flex items-center justify-center text-green-600 flex-shrink-0 mt-0.5"></i>
                          <span className="text-gray-700">{service}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Business Networking */}
      <section id="business-networking" className="py-20 bg-white scroll-mt-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-block bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl px-8 py-4 mb-6">
              <h2 className="text-4xl font-bold text-white">Business Networking</h2>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Connecting entrepreneurs and fostering business growth in local communities
            </p>
          </div>

          <div className="space-y-16">
            {businessPrograms.map((program, index) => (
              <div key={program.id} className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-8 items-center`}>
                <div className="lg:w-1/2">
                  <img
                    src={program.image}
                    alt={program.title}
                    className="w-full h-80 object-cover rounded-2xl shadow-lg"
                  />
                </div>
                <div className="lg:w-1/2">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">{program.title}</h3>
                  <div className="mb-4">
                    <p className={`text-gray-700 leading-relaxed ${!expandedSections[program.id] && program.description.length > 200 ? 'line-clamp-3' : ''}`}>
                      {program.description}
                    </p>
                    {program.description.length > 200 && (
                      <button
                        onClick={() => toggleSection(program.id)}
                        className="text-green-600 hover:text-green-700 font-medium mt-2 cursor-pointer"
                      >
                        {expandedSections[program.id] ? 'Read Less' : 'Read More'}
                      </button>
                    )}
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold text-gray-900 mb-3">Services Offered:</h4>
                    <ul className="space-y-2">
                      {program.services.map((service, serviceIndex) => (
                        <li key={serviceIndex} className="flex items-start space-x-2">
                          <i className="ri-check-line w-5 h-5 flex items-center justify-center text-green-600 flex-shrink-0 mt-0.5"></i>
                          <span className="text-gray-700">{service}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Office Locations */}
      <section id="office-locations" className="py-20 bg-gray-50 scroll-mt-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Locations</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Visit us at our offices in Toronto and Brampton to learn more about our programs and services.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {offices.map((office, index) => (
              <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-lg">
                <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                      <i className={`${office.icon} w-6 h-6 flex items-center justify-center text-white`}></i>
                    </div>
                    <h3 className="text-2xl font-bold text-white">{office.name}</h3>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="space-y-4 mb-6">
                    <div className="flex items-start space-x-3">
                      <i className="ri-map-pin-line w-5 h-5 flex items-center justify-center text-green-600 mt-1"></i>
                      <div>
                        <p className="text-gray-900 font-medium">{office.address}</p>
                        <p className="text-gray-700">{office.city}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-phone-line w-5 h-5 flex items-center justify-center text-green-600"></i>
                      <p className="text-gray-700">{office.phone}</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-mail-line w-5 h-5 flex items-center justify-center text-green-600"></i>
                      <p className="text-gray-700">{office.email}</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-time-line w-5 h-5 flex items-center justify-center text-green-600"></i>
                      <p className="text-gray-700">{office.hours}</p>
                    </div>
                  </div>

                  <div className="rounded-lg overflow-hidden h-64">
                    <iframe
                      src={office.mapUrl}
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title={`${office.name} Location`}
                    ></iframe>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-green-600">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Get Involved Today
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Whether you're a youth seeking support, a newcomer looking to integrate, or an entrepreneur wanting to connect, we're here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact"
              className="bg-white text-green-600 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap inline-block"
            >
              Contact Us
            </a>
            <a
              href="/partners#volunteer"
              className="bg-green-700 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-800 transition-colors cursor-pointer whitespace-nowrap inline-block"
            >
              Volunteer With Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

import { useState } from 'react';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export default function FAQPage() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const faqs: FAQItem[] = [
    {
      category: 'General',
      question: 'What is Livelihood Development International Initiatives (LDII)?',
      answer: 'LDII is a non-profit organization committed to creating a brighter future through the promotion of social cohesion and empowerment. We work globally to address critical challenges including climate resilience, health systems strengthening, food security, poverty eradication, and digital inclusion.'
    },
    {
      category: 'General',
      question: 'Where does LDII operate?',
      answer: 'LDII operates in over 25 countries across Africa, Asia-Pacific, Latin America, and North America. Our headquarters are in Toronto and Brampton, Ontario, Canada, with regional offices in Nairobi, Kenya and Kampala, Uganda.'
    },
    {
      category: 'General',
      question: 'How long has LDII been operating?',
      answer: 'LDII has over 10 years of experience in international development and community empowerment. During this time, we have served 250+ communities, implemented 45+ active projects, and partnered with 120+ global organizations.'
    },
    {
      category: 'Programs',
      question: 'What are LDII\'s main focus areas?',
      answer: 'LDII focuses on five key areas: 1) Climate Action & Mitigation, 2) Poverty Eradication & Inclusive Growth, 3) Sustainable Food Systems, 4) Global Health & Resilience, and 5) Digital Inclusion. Each focus area addresses critical global challenges through research, policy advocacy, and community-driven solutions.'
    },
    {
      category: 'Programs',
      question: 'What local programs does LDII offer in Canada?',
      answer: 'In Canada, LDII offers three main program streams: Youth Empowerment Initiative (including mental health support, employment readiness, arts programs, and more), Empowering Newcomers (settlement services, language training, employment support), and Business Networking (startup incubation, export development, professional networking).'
    },
    {
      category: 'Programs',
      question: 'How can I participate in LDII programs?',
      answer: 'You can participate in LDII programs by contacting us at info@ldiinitiatives.org or calling +1 (416) 660-4233. We offer various programs for youth, newcomers, and business professionals. Visit our Local Programs page for detailed information about eligibility and registration.'
    },
    {
      category: 'Partnerships',
      question: 'How can my organization partner with LDII?',
      answer: 'We welcome partnerships with government agencies, private sector companies, NGOs, and academic institutions. Partnership opportunities include collaborative research, program implementation, funding support, and knowledge sharing. Contact us at info@ldiinitiatives.org to discuss partnership possibilities.'
    },
    {
      category: 'Partnerships',
      question: 'Who are LDII\'s current partners?',
      answer: 'LDII partners with over 120 organizations globally, including the Government of Canada, World Bank, City of Brampton, Toronto Region Board of Trade, Canadian Hispanic Chamber of Commerce, and various international NGOs and academic institutions. Visit our Partners page for a complete list.'
    },
    {
      category: 'Donations',
      question: 'How can I donate to LDII?',
      answer: 'You can donate through our secure online donation page at www.ldiinitiatives.org/donate. We accept e-transfers (preferred method), credit/debit cards, direct bank transfers, and PayPal. All donations are tax-deductible, and you will receive a receipt for tax purposes.'
    },
    {
      category: 'Donations',
      question: 'Is my donation tax-deductible?',
      answer: 'Yes, LDII is a registered non-profit organization, and all donations are tax-deductible. You will receive an official tax receipt via email after your donation is processed.'
    },
    {
      category: 'Donations',
      question: 'How are donations used?',
      answer: 'Donations support our five focus areas: climate action, poverty eradication, sustainable food systems, global health, and digital inclusion. Funds are allocated to program implementation, research initiatives, community support, and operational costs. We maintain full transparency and publish annual reports detailing our financial activities.'
    },
    {
      category: 'Volunteer',
      question: 'How can I volunteer with LDII?',
      answer: 'We offer various volunteer opportunities including program support, event coordination, research assistance, and community outreach. Visit our Partners & Support page and fill out the volunteer application form, or contact us at info@ldiinitiatives.org.'
    },
    {
      category: 'Volunteer',
      question: 'What volunteer opportunities are available?',
      answer: 'Volunteer opportunities include: program facilitation, event planning and coordination, research and data analysis, community outreach, administrative support, and professional mentorship. Opportunities are available both in-person (Toronto/Brampton) and remotely.'
    },
    {
      category: 'Events',
      question: 'What events does LDII organize?',
      answer: 'LDII organizes international conferences, workshops, community events, and networking sessions. Major events include the Global Shocks Global South Conference, Cultural Resilience Conference (CROP), and NEABEC Summit. Visit our Events page for upcoming events and registration information.'
    },
    {
      category: 'Events',
      question: 'How can I attend LDII events?',
      answer: 'Event registration information is available on our Events page. Most conferences offer both in-person and virtual attendance options. Early bird registration discounts are often available. Contact info@ldiinitiatives.org for group registration or sponsorship opportunities.'
    },
    {
      category: 'Research',
      question: 'Does LDII publish research?',
      answer: 'Yes, LDII has published over 200 research papers, policy briefs, white papers, and reports. Our research covers topics including climate resilience, health systems, food security, economic development, and digital inclusion. All publications are available on our Research page.'
    },
    {
      category: 'Research',
      question: 'How can I access LDII research publications?',
      answer: 'All LDII research publications are freely available on our website under the Research section. You can browse by category (Policy Briefs, Publications, White Papers, Data & Statistics) or search by topic. Publications can be downloaded in PDF format.'
    },
    {
      category: 'Contact',
      question: 'How can I contact LDII?',
      answer: 'You can reach us by phone at +1 (416) 660-4233 or email at info@ldiinitiatives.org. Our Toronto office is located at 3701 Chesswood Drive, Unit 315, Toronto, ON M3J 2P6. Our Brampton office is at 101 West Dr C, Brampton, ON L6T 2J6. Office hours are Monday-Friday, 9:00 AM - 5:00 PM EST.'
    },
    {
      category: 'Contact',
      question: 'Does LDII have regional offices?',
      answer: 'Yes, in addition to our Canadian headquarters in Toronto and Brampton, we have regional offices in Nairobi, Kenya and Kampala, Uganda. All offices can be reached through our main email: info@ldiinitiatives.org.'
    },
    {
      category: 'Media',
      question: 'How can media contact LDII?',
      answer: 'For media inquiries, press releases, and interview requests, please contact us at info@ldiinitiatives.org or call +1 (416) 660-4233. You can also submit a media inquiry form on our Contact page under Media Inquiries.'
    }
  ];

  const categories = ['all', 'General', 'Programs', 'Partnerships', 'Donations', 'Volunteer', 'Events', 'Research', 'Contact', 'Media'];

  const filteredFAQs = activeCategory === 'all' 
    ? faqs 
    : faqs.filter(faq => faq.category === activeCategory);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section id="hero" className="bg-gradient-to-br from-green-600 to-emerald-700 py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            Frequently Asked Questions
          </h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Find answers to common questions about LDII, our programs, partnerships, and how you can get involved.
          </p>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {/* Category Filter */}
          <div className="mb-12">
            <div className="flex flex-wrap gap-3 justify-center">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-6 py-2 rounded-full font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap ${
                    activeCategory === category
                      ? 'bg-green-600 text-white shadow-lg'
                      : 'bg-white text-gray-700 hover:bg-green-50 border border-gray-200'
                  }`}
                >
                  {category === 'all' ? 'All Questions' : category}
                </button>
              ))}
            </div>
          </div>

          {/* FAQ List */}
          <div className="max-w-4xl mx-auto space-y-4">
            {filteredFAQs.map((faq, index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg"
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full px-6 py-5 text-left flex items-center justify-between cursor-pointer hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1">
                    <span className="inline-block px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full mb-2">
                      {faq.category}
                    </span>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {faq.question}
                    </h3>
                  </div>
                  <div className={`ml-4 transform transition-transform duration-300 ${openIndex === index ? 'rotate-180' : ''}`}>
                    <i className="ri-arrow-down-s-line text-2xl text-gray-600"></i>
                  </div>
                </button>
                
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-96' : 'max-h-0'
                  }`}
                >
                  <div className="px-6 pb-5 text-gray-700 leading-relaxed">
                    {faq.answer}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Contact CTA */}
          <div className="mt-16 text-center bg-white rounded-2xl shadow-lg p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Still Have Questions?
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Can't find the answer you're looking for? Our team is here to help. Reach out to us directly.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/contact#hero"
                className="bg-green-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                Contact Us
              </a>
              <a
                href="mailto:info@ldiinitiatives.org"
                className="bg-white text-green-600 border-2 border-green-600 px-8 py-4 rounded-lg font-semibold hover:bg-green-50 transition-colors cursor-pointer whitespace-nowrap"
              >
                Email Us
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

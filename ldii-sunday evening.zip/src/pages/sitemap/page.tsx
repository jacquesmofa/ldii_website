export default function SitemapPage() {
  const sitemapSections = [
    {
      title: 'Main Pages',
      links: [
        { name: 'Home', url: '/#hero' },
        { name: 'About Us', url: '/about#hero' },
        { name: 'Contact', url: '/contact#hero' },
        { name: 'Donate', url: '/donate#hero' },
      ]
    },
    {
      title: 'About',
      links: [
        { name: 'Who We Are', url: '/about/who-we-are#hero' },
        { name: 'Our Work', url: '/about/our-work#hero' },
        { name: 'Past Projects', url: '/about/past-projects#hero' },
        { name: 'Upcoming Projects', url: '/about/upcoming-projects#hero' },
      ]
    },
    {
      title: 'What We Do',
      links: [
        { name: 'Overview', url: '/what-we-do#hero' },
        { name: 'Climate Action & Mitigation', url: '/what-we-do/climate-action#hero' },
        { name: 'Poverty Eradication & Inclusive Growth', url: '/what-we-do/poverty-eradication#hero' },
        { name: 'Sustainable Food Systems', url: '/what-we-do/sustainable-food#hero' },
        { name: 'Global Health & Resilience', url: '/what-we-do/global-health#hero' },
        { name: 'Digital Inclusion', url: '/what-we-do/digital-inclusion#hero' },
      ]
    },
    {
      title: 'Focus Areas',
      links: [
        { name: 'All Focus Areas', url: '/focus-areas#hero' },
      ]
    },
    {
      title: 'Local Programs',
      links: [
        { name: 'Local Programs (Canada & Ontario)', url: '/local-programs#hero' },
      ]
    },
    {
      title: 'Impact',
      links: [
        { name: 'Overview', url: '/impact#hero' },
        { name: 'Achievements', url: '/impact/achievements#hero' },
        { name: 'Success Stories', url: '/impact/success-stories#hero' },
        { name: 'Annual Reports', url: '/impact/annual-reports#hero' },
        { name: 'Metrics', url: '/impact/metrics#hero' },
      ]
    },
    {
      title: 'Events & News',
      links: [
        { name: 'Overview', url: '/events#hero' },
        { name: 'Upcoming Events', url: '/events/upcoming#hero' },
        { name: 'Past Events & Resources', url: '/events/past#hero' },
        { name: 'Latest News', url: '/events/news#hero' },
        { name: 'Press Releases', url: '/events/news/press-releases#hero' },
        { name: 'Gallery', url: '/events/gallery#hero' },
      ]
    },
    {
      title: 'Research',
      links: [
        { name: 'Overview', url: '/research#hero' },
        { name: 'Policy Briefs', url: '/research/policy-briefs#hero' },
        { name: 'Publications', url: '/research/publications#hero' },
        { name: 'Data & Statistics', url: '/research/data-statistics#hero' },
        { name: 'White Papers', url: '/research/white-papers#hero' },
      ]
    },
    {
      title: 'Partners & Support',
      links: [
        { name: 'Overview', url: '/partners#hero' },
        { name: 'Government Partners', url: '/partners#government-partners' },
        { name: 'Private Sector', url: '/partners#private-sector' },
        { name: 'NGO Partners', url: '/partners#ngo-partners' },
        { name: 'Academic Institutions', url: '/partners#academic-institutions' },
        { name: 'Donate', url: '/partners#donate' },
        { name: 'Volunteer', url: '/partners#volunteer' },
        { name: 'Corporate Partnership', url: '/partners#corporate-partnership' },
      ]
    },
    {
      title: 'Contact',
      links: [
        { name: 'Get in Touch', url: '/contact/get-in-touch#hero' },
        { name: 'Our Locations', url: '/contact/our-locations#hero' },
        { name: 'Media Inquiries', url: '/contact/media-inquiries#hero' },
      ]
    },
    {
      title: 'Legal & Resources',
      links: [
        { name: 'Privacy Policy', url: '/privacy-policy#hero' },
        { name: 'Terms of Service', url: '/terms-of-service#hero' },
        { name: 'Accessibility Statement', url: '/accessibility#hero' },
        { name: 'FAQs', url: '/faq#hero' },
        { name: 'Sitemap', url: '/sitemap#hero' },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section id="hero" className="bg-gradient-to-br from-green-600 to-emerald-700 py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            Sitemap
          </h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Navigate through all pages and sections of the LDII website. Find exactly what you're looking for.
          </p>
        </div>
      </section>

      {/* Sitemap Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sitemapSections.map((section, index) => (
              <div key={index} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
                <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-3 border-b-2 border-green-600">
                  {section.title}
                </h2>
                <ul className="space-y-2">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <a
                        href={link.url}
                        className="text-gray-700 hover:text-green-600 transition-colors flex items-center group cursor-pointer"
                      >
                        <i className="ri-arrow-right-s-line text-green-600 mr-2 group-hover:translate-x-1 transition-transform"></i>
                        {link.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Quick Access Section */}
          <div className="mt-16 bg-gradient-to-br from-green-600 to-emerald-700 rounded-2xl shadow-xl p-12 text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Quick Access
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
              Looking for something specific? Use these quick links to access our most popular pages.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <a
                href="/donate#hero"
                className="bg-white text-green-600 px-6 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                Donate Now
              </a>
              <a
                href="/local-programs#hero"
                className="bg-white text-green-600 px-6 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                Local Programs
              </a>
              <a
                href="/events/upcoming#hero"
                className="bg-white text-green-600 px-6 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                Upcoming Events
              </a>
              <a
                href="/contact#hero"
                className="bg-white text-green-600 px-6 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                Contact Us
              </a>
            </div>
          </div>

          {/* Search Help */}
          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-4">
              Can't find what you're looking for?
            </p>
            <a
              href="/contact#hero"
              className="text-green-600 font-semibold hover:text-green-700 transition-colors cursor-pointer"
            >
              Contact us for assistance →
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
